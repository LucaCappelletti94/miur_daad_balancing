"""Current version of package miur_daad_balancing"""
__version__ = "1.0.0"